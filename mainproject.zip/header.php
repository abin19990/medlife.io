<!DOCTYPE html>
<html lang="zxx">
<head>
	<meta charset="utf-8">
	<meta content="IE=edge" http-equiv="X-UA-Compatible">
	<meta content="width=device-width, initial-scale=1" name="viewport">
	<title>Hospital</title><!-- Favicon -->
	<link href="images/favicon.ico" rel="icon" type="image/x-icon"><!-- Font Awesome -->
	<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet"><!-- Bootstrap -->
	<link href="css/bootstrap.css" rel="stylesheet"><!--=== Add By Designer ===-->
	<link href="css/style.css" rel="stylesheet">
	<link href="fonts/fonts.css" rel="stylesheet"><!-- Yamm Megamenu -->
	<link href="css/yamm.css" rel="stylesheet"><!-- Animation -->
	<link href="css/animate.css" rel="stylesheet">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
	
	
	<!-- Animation -->
	<!-- Flat Icon -->
	<link href="fonts/flaticon.css" rel="stylesheet"><!-- Flat Icon -->
	<!-- Multi Level Push Menu -->
	<link href="css/normalize.css" rel="stylesheet">
	<link href="css/component.css" rel="stylesheet">
	<script src="js/modernizr.custom.js">
	</script><!-- Multi Level Push Menu -->
	<!-- REVOLUTION STYLE SHEETS -->
	<link href="js/revslider/settings.css" rel="stylesheet" type="text/css">
	<link href="js/revslider/layers.css" rel="stylesheet" type="text/css">
	<link href="js/revslider/navigation.css" rel="stylesheet" type="text/css"><!-- REVOLUTION LAYERS STYLES -->
</head>
<body>
	<!-- Header Start -->
	
	<!-- Slider Start -->