<?php require_once('header.php') ?>
<?php require_once('menu.php') ?>
<div class="main-slider clearfix">
		<div class="rev_slider fullscreen" data-version="5.3.0.2" id="rev_slider_1_1" style="display:none;">
			<ul>
				<!-- SLIDE  -->
				<li data-description="" data-easein="default" data-easeout="default" data-hideafterloop="0" data-hideslideonmobile="off" data-index="rs-1" data-masterspeed="300" data-param1="" data-param10="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-rotate="0" data-saveperformance="off" data-slotamount="default" data-title="Slide" data-transition="slotzoom-horizontal">
					<!-- MAIN IMAGE -->
					<img alt="" class="rev-slidebg" data-bgfit="cover" data-bgposition="center center" data-bgrepeat="no-repeat" data-no-retina="" src="images/wp2968489-medical-doctor-wallpaper-hd.jpg" title="Home"> <!-- LAYERS 1-->
					<div class="tp-caption tp-shape tp-shapewrapper tp-resizeme" data-frames="[{&quot;delay&quot;:0,&quot;speed&quot;:10,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;opacity:0;&quot;,&quot;to&quot;:&quot;o:1;&quot;,&quot;ease&quot;:&quot;Power2.easeInOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:2260,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;opacity:0;&quot;,&quot;ease&quot;:&quot;nothing&quot;}]" data-height="4000" data-hoffset="['0','0','0','0']" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingtop="[0,0,0,0]" data-responsive_offset="on" data-textalign="['left','left','left','left']" data-type="shape" data-voffset="['0','0','0','0']" data-whitespace="nowrap" data-width="4000" data-x="['center','center','center','center']" data-y="['middle','middle','middle','middle']" id="slide-1-layer-1" style="z-index: 5;background-color:rgba(0, 0, 0, 0.25);border-color:rgba(0, 0, 0, 0);"></div><!-- LAYER NR. 2 -->
					<div class="tp-caption" data-fontsize="['72','62','50','28']" data-frames="[{&quot;delay&quot;:500,&quot;speed&quot;:1500,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;x:[175%];y:0px;z:0;rX:0;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:1;&quot;,&quot;mask&quot;:&quot;x:[-100%];y:0;s:inherit;e:inherit;&quot;,&quot;to&quot;:&quot;o:1;&quot;,&quot;ease&quot;:&quot;Power3.easeOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:300,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;opacity:0;&quot;,&quot;ease&quot;:&quot;nothing&quot;}]" data-height="['81','66','61','36']" data-hoffset="['29','21','-4','-3']" data-lineheight="['80','65','60','34']" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingtop="[0,0,0,0]" data-responsive="off" data-responsive_offset="off" data-textalign="['left','left','left','left']" data-type="text" data-voffset="['392','386','-110','-64']" data-whitespace="nowrap" data-width="['385','333','271','152']" data-x="['left','left','center','center']" data-y="['bottom','bottom','middle','middle']" id="slide-1-layer-2" style="z-index: 6; min-width: 385px; max-width: 385px; max-width: 81px; max-width: 81px; white-space: nowrap; font-size: 72px; line-height: 80px; font-weight: 400; color: rgba(255, 255, 255, 1.00);font-family: 'latoregular';">
						Health Care
					</div><!-- LAYER NR. 3 -->
					<div class="tp-caption" data-fontsize="['30','26','22','16']" data-frames="[{&quot;delay&quot;:500,&quot;speed&quot;:1500,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;x:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;&quot;,&quot;mask&quot;:&quot;x:0px;y:0px;s:inherit;e:inherit;&quot;,&quot;to&quot;:&quot;o:1;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:300,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;opacity:0;&quot;,&quot;ease&quot;:&quot;nothing&quot;}]" data-height="['73','none','57','41']" data-hoffset="['30','24','-3','-4']" data-lineheight="['36','30','28','20']" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingtop="[0,0,0,0]" data-responsive="off" data-responsive_offset="off" data-textalign="['left','left','center','center']" data-type="text" data-voffset="['315','315','-46','-24']" data-whitespace="nowrap" data-width="['422','none','307','225']" data-x="['left','left','center','center']" data-y="['bottom','bottom','middle','middle']" id="slide-1-layer-3" style="z-index: 7; min-width: 422px; max-width: 422px; max-width: 73px; max-width: 73px; white-space: nowrap; font-size: 30px; line-height: 36px; font-weight: 300; color: rgba(255, 255, 255, 1.00);font-family: 'latolight';">
						Renowned pediatricians work at<br>
						MedLife Pediatric Hospital.
					</div><a class="tp-caption rev-btn" data-actions="" data-frames="[{&quot;delay&quot;:500,&quot;speed&quot;:300,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;opacity:0;&quot;,&quot;to&quot;:&quot;o:1;&quot;,&quot;ease&quot;:&quot;Power2.easeInOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:300,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;opacity:0;&quot;,&quot;ease&quot;:&quot;nothing&quot;},{&quot;frame&quot;:&quot;hover&quot;,&quot;speed&quot;:&quot;0&quot;,&quot;ease&quot;:&quot;Linear.easeNone&quot;,&quot;force&quot;:true,&quot;to&quot;:&quot;o:1;rX:0;rY:0;rZ:0;z:0;&quot;,&quot;style&quot;:&quot;c:rgba(255, 255, 255, 1.00);bg:rgba(76, 171, 76, 1.00);bs:solid;bw:0 0 0 0;&quot;}]" data-height="['53','53','54','42']" data-hoffset="['31','26','-2','-2']" data-lineheight="['28','28','28','16']" data-paddingbottom="[12,12,12,12]" data-paddingleft="[35,35,35,35]" data-paddingright="[35,35,35,35]" data-paddingtop="[12,12,12,12]" data-responsive="off" data-responsive_offset="off" data-textalign="['left','left','center','center']" data-type="button" data-voffset="['241','241','27','27']" data-whitespace="nowrap" data-width="['148','148','210','151']" data-x="['left','left','center','center']" data-y="['bottom','bottom','middle','middle']" href="services/index.html" id="slide-1-layer-4" style="z-index: 8; min-width: 148px; max-width: 148px; max-width: 53px; max-width: 53px; white-space: nowrap; font-size: 14px; line-height: 28px; font-weight: 700; color: rgba(255, 255, 255, 1.00);font-family: 'latoregular';background-color:rgba(219, 25, 25, 1.00);border-color:rgba(0, 0, 0, 1.00);border-radius:3px 3px 3px 3px;outline:none;box-shadow:none;box-sizing:border-box;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;cursor:pointer;" target="_self">FIND MORE</a>
				</li><!-- SLIDE  -->
				<!-- SLIDE  -->
				<li data-description="" data-easein="default" data-easeout="default" data-hideafterloop="0" data-hideslideonmobile="off" data-index="rs-2" data-masterspeed="300" data-param1="" data-param10="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-rotate="0" data-saveperformance="off" data-slotamount="default" data-title="Slide" data-transition="slotzoom-horizontal">
					<img alt="" class="rev-slidebg" data-bgfit="cover" data-bgposition="center center" data-no-retina="" src="images/fro.jpg" title="Home"> <!-- <div class="rs-background-video-layer" data-forcerewind="on" data-volume="mute" data-ytid="w0zelS2nX2E" data-videoattributes="version=3&enablejsapi=1&html5=1&hd=1&wmode=opaque&showinfo=0&rel=0;;origin=https://demo.kallyas.net;" data-videorate="1" data-videowidth="100%" data-videoheight="100%" data-videocontrols="none" data-videoloop="none" data-forceCover="1" data-aspectratio="16:9" data-autoplay="true" data-autoplayonlyfirsttime="false" data-nextslideatend="true"></div> -->
					<div class="rs-background-video-layer" data-aspectratio="16:9" data-autoplay="true" data-autoplayonlyfirsttime="false" data-forcecover="1" data-forcerewind="on" data-videoheight="100%" data-videoloop="loopandnoslidestop" data-videomp4="images/Comp 1 1.mp4" data-videopreload="auto" data-videowidth="100%" data-volume="mute"></div>
					<div class="tp-caption tp-shape tp-shapewrapper tp-resizeme" data-frames="[{&quot;delay&quot;:0,&quot;speed&quot;:10,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;opacity:0;&quot;,&quot;to&quot;:&quot;o:1;&quot;,&quot;ease&quot;:&quot;Power2.easeInOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:2260,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;opacity:0;&quot;,&quot;ease&quot;:&quot;nothing&quot;}]" data-height="4000" data-hoffset="['0','0','0','0']" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingtop="[0,0,0,0]" data-responsive_offset="on" data-textalign="['left','left','left','left']" data-type="shape" data-voffset="['0','0','0','0']" data-whitespace="nowrap" data-width="4000" data-x="['center','center','center','center']" data-y="['middle','middle','middle','middle']" id="slide-2-layer-1" style="z-index: 5;background-color:rgba(0, 0, 0, 0.25);border-color:rgba(0, 0, 0, 0);"></div>
					<div class="tp-caption" data-fontsize="['72','62','50','28']" data-frames="[{&quot;delay&quot;:500,&quot;speed&quot;:1500,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;x:[175%];y:0px;z:0;rX:0;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:1;&quot;,&quot;mask&quot;:&quot;x:[-100%];y:0;s:inherit;e:inherit;&quot;,&quot;to&quot;:&quot;o:1;&quot;,&quot;ease&quot;:&quot;Power3.easeOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:300,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;opacity:0;&quot;,&quot;ease&quot;:&quot;nothing&quot;}]" data-height="['161','131','121','69']" data-hoffset="['29','22','-4','-3']" data-lineheight="['80','65','60','34']" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingtop="[0,0,0,0]" data-responsive="off" data-responsive_offset="off" data-textalign="['left','left','center','center']" data-type="text" data-voffset="['392','386','-130','-82']" data-whitespace="normal" data-width="['416','352','284','168']" data-x="['left','left','center','center']" data-y="['bottom','bottom','middle','middle']" id="slide-2-layer-2" style="z-index: 6; min-width: 416px; max-width: 416px; max-width: 161px; max-width: 161px; white-space: normal; font-size: 72px; line-height: 80px; font-weight: 400; color: rgba(255, 255, 255, 1.00);font-family: 'latoregular';">
						Medical Radiography
					</div>
					<div class="tp-caption" data-fontsize="['30','26','22','16']" data-frames="[{&quot;delay&quot;:500,&quot;speed&quot;:1500,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;x:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;&quot;,&quot;mask&quot;:&quot;x:0px;y:0px;s:inherit;e:inherit;&quot;,&quot;to&quot;:&quot;o:1;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:300,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;opacity:0;&quot;,&quot;ease&quot;:&quot;nothing&quot;}]" data-height="none" data-hoffset="['30','24','-3','-4']" data-lineheight="['36','30','28','20']" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingtop="[0,0,0,0]" data-responsive="off" data-responsive_offset="off" data-textalign="['left','left','center','center']" data-type="text" data-voffset="['315','316','-46','-24']" data-whitespace="normal" data-width="['423','369','308','226']" data-x="['left','left','center','center']" data-y="['bottom','bottom','middle','middle']" id="slide-2-layer-3" style="z-index: 7; min-width: 423px; max-width: 423px; white-space: normal; font-size: 30px; line-height: 36px; font-weight: 300; color: rgba(255, 255, 255, 1.00);font-family: 'latolight';">
						Brussels finest outpatient diagnostic imaging center
					</div><a class="tp-caption rev-btn" data-actions="" data-frames="[{&quot;delay&quot;:500,&quot;speed&quot;:300,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;opacity:0;&quot;,&quot;to&quot;:&quot;o:1;&quot;,&quot;ease&quot;:&quot;Power2.easeInOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:300,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;opacity:0;&quot;,&quot;ease&quot;:&quot;nothing&quot;},{&quot;frame&quot;:&quot;hover&quot;,&quot;speed&quot;:&quot;0&quot;,&quot;ease&quot;:&quot;Linear.easeNone&quot;,&quot;force&quot;:true,&quot;to&quot;:&quot;o:1;rX:0;rY:0;rZ:0;z:0;&quot;,&quot;style&quot;:&quot;c:rgba(255, 255, 255, 1.00);bg:rgba(76, 171, 76, 1.00);bs:solid;bw:0 0 0 0;&quot;}]" data-height="['53','53','54','42']" data-hoffset="['31','26','-2','-2']" data-lineheight="['28','28','28','16']" data-paddingbottom="[12,12,12,12]" data-paddingleft="[35,35,35,35]" data-paddingright="[35,35,35,35]" data-paddingtop="[12,12,12,12]" data-responsive="off" data-responsive_offset="off" data-textalign="['left','left','center','center']" data-type="button" data-voffset="['241','241','27','27']" data-whitespace="nowrap" data-width="['148','148','210','151']" data-x="['left','left','center','center']" data-y="['bottom','bottom','middle','middle']" href="services/index.html" id="slide-2-layer-4" style="z-index: 8; min-width: 148px; max-width: 148px; max-width: 53px; max-width: 53px; white-space: nowrap; font-size: 14px; line-height: 28px; font-weight: 700; color: rgba(255, 255, 255, 1.00);font-family: 'latoregular';background-color:rgba(219, 25, 25, 1.00);border-color:rgba(0, 0, 0, 1.00);border-radius:3px 3px 3px 3px;outline:none;box-shadow:none;box-sizing:border-box;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;cursor:pointer;" target="_self">FIND MORE</a>
				</li><!-- SLIDE  -->
				<!-- SLIDE  -->
				<li data-description="" data-easein="default" data-easeout="default" data-hideafterloop="0" data-hideslideonmobile="off" data-index="rs-3" data-masterspeed="300" data-param1="" data-param10="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-rotate="0" data-saveperformance="off" data-slotamount="default" data-title="Slide" data-transition="slotzoom-horizontal">
					<img alt="" class="rev-slidebg" data-bgfit="cover" data-bgposition="center top" data-bgrepeat="no-repeat" data-no-retina="" src="images/fro2.jpg" title="Home">
					<div class="tp-caption tp-shape tp-shapewrapper tp-resizeme" data-frames="[{&quot;delay&quot;:0,&quot;speed&quot;:10,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;opacity:0;&quot;,&quot;to&quot;:&quot;o:1;&quot;,&quot;ease&quot;:&quot;Power2.easeInOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:2260,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;opacity:0;&quot;,&quot;ease&quot;:&quot;nothing&quot;}]" data-height="4000" data-hoffset="['0','0','0','0']" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingtop="[0,0,0,0]" data-responsive_offset="on" data-textalign="['left','left','left','left']" data-type="shape" data-voffset="['0','0','0','0']" data-whitespace="nowrap" data-width="4000" data-x="['center','center','center','center']" data-y="['middle','middle','middle','middle']" id="slide-3-layer-1" style="z-index: 5;background-color:rgba(0, 0, 0, 0.25);border-color:rgba(0, 0, 0, 0);"></div>
					<div class="tp-caption" data-fontsize="['72','62','50','28']" data-frames="[{&quot;delay&quot;:500,&quot;speed&quot;:1500,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;x:[175%];y:0px;z:0;rX:0;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:1;&quot;,&quot;mask&quot;:&quot;x:[-100%];y:0;s:inherit;e:inherit;&quot;,&quot;to&quot;:&quot;o:1;&quot;,&quot;ease&quot;:&quot;Power3.easeOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:300,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;opacity:0;&quot;,&quot;ease&quot;:&quot;nothing&quot;}]" data-height="['243','196','182','104']" data-hoffset="['27','22','-4','-3']" data-lineheight="['80','65','60','34']" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingtop="[0,0,0,0]" data-responsive="off" data-responsive_offset="off" data-textalign="['left','left','center','center']" data-type="text" data-voffset="['330','334','-110','-64']" data-whitespace="normal" data-width="['530','447','370','207']" data-x="['left','left','center','center']" data-y="['bottom','bottom','middle','middle']" id="slide-3-layer-2" style="z-index: 6; min-width: 530px; max-width: 530px; max-width: 243px; max-width: 243px; white-space: normal; font-size: 72px; line-height: 80px; font-weight: 400; color: rgba(255, 255, 255, 1.00);font-family: 'latoregular';">
						Internal & Family Medicine
					</div>
					<div class="tp-caption" data-fontsize="['30','26','22','16']" data-frames="[{&quot;delay&quot;:500,&quot;speed&quot;:1500,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;x:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;&quot;,&quot;mask&quot;:&quot;x:0px;y:0px;s:inherit;e:inherit;&quot;,&quot;to&quot;:&quot;o:1;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:300,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;opacity:0;&quot;,&quot;ease&quot;:&quot;nothing&quot;}]" data-height="['109','none','85','61']" data-hoffset="['30','24','-3','-4']" data-lineheight="['36','30','28','20']" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingtop="[0,0,0,0]" data-responsive="off" data-responsive_offset="off" data-textalign="['left','left','center','center']" data-type="text" data-voffset="['286','315','-32','-16']" data-whitespace="normal" data-width="['450','431','336','251']" data-x="['left','left','center','center']" data-y="['bottom','bottom','middle','middle']" id="slide-3-layer-3" style="z-index: 7; min-width: 443px; max-width: 443px; max-width: 109px; max-width: 109px; white-space: normal; font-size: 30px; line-height: 36px; font-weight: 300; color: rgba(255, 255, 255, 1.00);font-family: 'latolight';">
						Family doctors are the most widely skilled primary care doctors
					</div><a class="tp-caption rev-btn" data-actions="" data-frames="[{&quot;delay&quot;:500,&quot;speed&quot;:300,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;opacity:0;&quot;,&quot;to&quot;:&quot;o:1;&quot;,&quot;ease&quot;:&quot;Power2.easeInOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:300,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;opacity:0;&quot;,&quot;ease&quot;:&quot;nothing&quot;},{&quot;frame&quot;:&quot;hover&quot;,&quot;speed&quot;:&quot;0&quot;,&quot;ease&quot;:&quot;Linear.easeNone&quot;,&quot;force&quot;:true,&quot;to&quot;:&quot;o:1;rX:0;rY:0;rZ:0;z:0;&quot;,&quot;style&quot;:&quot;c:rgba(255, 255, 255, 1.00);bg:rgba(76, 171, 76, 1.00);bs:solid;bw:0 0 0 0;&quot;}]" data-height="['53','53','54','42']" data-hoffset="['32','26','-2','-2']" data-lineheight="['28','28','28','16']" data-paddingbottom="[12,12,12,12]" data-paddingleft="[35,35,35,35]" data-paddingright="[35,35,35,35]" data-paddingtop="[12,12,12,12]" data-responsive="off" data-responsive_offset="off" data-textalign="['left','left','center','center']" data-type="button" data-voffset="['241','241','27','27']" data-whitespace="nowrap" data-width="['148','148','210','151']" data-x="['left','left','center','center']" data-y="['bottom','bottom','middle','middle']" href="pediatric-dentistry/index.html" id="slide-3-layer-4" style="z-index: 8; min-width: 148px; max-width: 148px; max-width: 53px; max-width: 53px; white-space: nowrap; font-size: 14px; line-height: 28px; font-weight: 700; color: rgba(255, 255, 255, 1.00);font-family: 'latoregular';background-color:rgba(219, 25, 25, 1.00);border-color:rgba(0, 0, 0, 1.00);border-radius:3px 3px 3px 3px;outline:none;box-shadow:none;box-sizing:border-box;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;cursor:pointer;" target="_self">FIND MORE</a>
				</li><!-- SLIDE  -->
				<!-- SLIDE  -->
				<li data-description="" data-easein="default" data-easeout="default" data-hideafterloop="0" data-hideslideonmobile="off" data-index="rs-4" data-masterspeed="300" data-param1="" data-param10="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-rotate="0" data-saveperformance="off" data-slotamount="default" data-title="Slide" data-transition="slotzoom-horizontal">
					<img alt="" class="rev-slidebg" data-bgfit="cover" data-bgposition="center center" data-bgrepeat="no-repeat" data-no-retina="" src="images/medibg2.jpg" title="Home">
					<div class="tp-caption tp-shape tp-shapewrapper tp-resizeme" data-frames="[{&quot;delay&quot;:0,&quot;speed&quot;:10,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;opacity:0;&quot;,&quot;to&quot;:&quot;o:1;&quot;,&quot;ease&quot;:&quot;Power2.easeInOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:2260,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;opacity:0;&quot;,&quot;ease&quot;:&quot;nothing&quot;}]" data-height="4000" data-hoffset="['0','0','0','0']" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingtop="[0,0,0,0]" data-responsive_offset="on" data-textalign="['left','left','left','left']" data-type="shape" data-voffset="['0','0','0','0']" data-whitespace="nowrap" data-width="4000" data-x="['center','center','center','center']" data-y="['middle','middle','middle','middle']" id="slide-4-layer-1" style="z-index: 5;background-color:rgba(0, 0, 0, 0.25);border-color:rgba(0, 0, 0, 0);"></div>
					<div class="tp-caption" data-fontsize="['72','62','50','28']" data-frames="[{&quot;delay&quot;:500,&quot;speed&quot;:1500,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;x:[175%];y:0px;z:0;rX:0;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:1;&quot;,&quot;mask&quot;:&quot;x:[-100%];y:0;s:inherit;e:inherit;&quot;,&quot;to&quot;:&quot;o:1;&quot;,&quot;ease&quot;:&quot;Power3.easeOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:300,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;opacity:0;&quot;,&quot;ease&quot;:&quot;nothing&quot;}]" data-height="['243','197','181','103']" data-hoffset="['26','21','-4','-3']" data-lineheight="['80','65','60','34']" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingtop="[0,0,0,0]" data-responsive="off" data-responsive_offset="off" data-textalign="['left','left','center','center']" data-type="text" data-voffset="['324','332','-110','-64']" data-whitespace="normal" data-width="['501','431','329','193']" data-x="['left','left','center','center']" data-y="['bottom','bottom','middle','middle']" id="slide-4-layer-2" style="z-index: 6; min-width: 501px; max-width: 501px; max-width: 243px; max-width: 243px; white-space: normal; font-size: 72px; line-height: 80px; font-weight: 400; color: rgba(255, 255, 255, 1.00);font-family: 'latoregular';">
						Comprehensive Breast Center
					</div>
					<div class="tp-caption" data-fontsize="['30','26','22','16']" data-frames="[{&quot;delay&quot;:500,&quot;speed&quot;:1500,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;x:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;&quot;,&quot;mask&quot;:&quot;x:0px;y:0px;s:inherit;e:inherit;&quot;,&quot;to&quot;:&quot;o:1;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:300,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;opacity:0;&quot;,&quot;ease&quot;:&quot;nothing&quot;}]" data-height="['73','none','57','41']" data-hoffset="['30','24','-3','-4']" data-lineheight="['36','30','28','20']" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingtop="[0,0,0,0]" data-responsive="off" data-responsive_offset="off" data-textalign="['left','left','center','center']" data-type="text" data-voffset="['315','315','-46','-25']" data-whitespace="nowrap" data-width="['422','none','307','225']" data-x="['left','left','center','center']" data-y="['bottom','bottom','middle','middle']" id="slide-4-layer-3" style="z-index: 7; min-width: 422px; max-width: 422px; max-width: 73px; max-width: 73px; white-space: nowrap; font-size: 30px; line-height: 36px; font-weight: 300; color: rgba(255, 255, 255, 1.00);font-family: 'latolight';">
						We are here to help, guide<br>
						and support you.
					</div><a class="tp-caption rev-btn" data-actions="" data-frames="[{&quot;delay&quot;:500,&quot;speed&quot;:300,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;opacity:0;&quot;,&quot;to&quot;:&quot;o:1;&quot;,&quot;ease&quot;:&quot;Power2.easeInOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:300,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;opacity:0;&quot;,&quot;ease&quot;:&quot;nothing&quot;},{&quot;frame&quot;:&quot;hover&quot;,&quot;speed&quot;:&quot;0&quot;,&quot;ease&quot;:&quot;Linear.easeNone&quot;,&quot;force&quot;:true,&quot;to&quot;:&quot;o:1;rX:0;rY:0;rZ:0;z:0;&quot;,&quot;style&quot;:&quot;c:rgba(255, 255, 255, 1.00);bg:rgba(76, 171, 76, 1.00);bs:solid;bw:0 0 0 0;&quot;}]" data-height="['53','53','54','42']" data-hoffset="['31','26','-2','-2']" data-lineheight="['28','28','28','16']" data-paddingbottom="[12,12,12,12]" data-paddingleft="[35,35,35,35]" data-paddingright="[35,35,35,35]" data-paddingtop="[12,12,12,12]" data-responsive="off" data-responsive_offset="off" data-textalign="['left','left','center','center']" data-type="button" data-voffset="['241','241','27','27']" data-whitespace="nowrap" data-width="['148','148','210','151']" data-x="['left','left','center','center']" data-y="['bottom','bottom','middle','middle']" href="services/index.html" id="slide-4-layer-4" style="z-index: 8; min-width: 148px; max-width: 148px; max-width: 53px; max-width: 53px; white-space: nowrap; font-size: 14px; line-height: 28px; font-weight: 700; color: rgba(255, 255, 255, 1.00);font-family: 'latoregular';background-color:rgba(102, 204, 102, 1.00);border-color:rgba(0, 0, 0, 1.00);border-radius:3px 3px 3px 3px;outline:none;box-shadow:none;box-sizing:border-box;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;cursor:pointer;" target="_self">FIND MORE</a>
				</li><!-- SLIDE  -->
				<!-- SLIDE  -->
				<li data-description="" data-easein="default" data-easeout="default" data-hideafterloop="0" data-hideslideonmobile="off" data-index="rs-5" data-masterspeed="300" data-param1="" data-param10="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-rotate="0" data-saveperformance="off" data-slotamount="default" data-title="Slide" data-transition="slotzoom-horizontal">
					<img alt="" class="rev-slidebg" data-bgfit="cover" data-bgposition="center center" data-bgrepeat="no-repeat" data-no-retina="" src="images/medibg3.jpg" title="Home">
					<div class="tp-caption tp-shape tp-shapewrapper tp-resizeme" data-frames="[{&quot;delay&quot;:0,&quot;speed&quot;:10,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;opacity:0;&quot;,&quot;to&quot;:&quot;o:1;&quot;,&quot;ease&quot;:&quot;Power2.easeInOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:2260,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;opacity:0;&quot;,&quot;ease&quot;:&quot;nothing&quot;}]" data-height="4000" data-hoffset="['0','0','0','0']" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingtop="[0,0,0,0]" data-responsive_offset="on" data-textalign="['left','left','left','left']" data-type="shape" data-voffset="['0','0','0','0']" data-whitespace="nowrap" data-width="4000" data-x="['center','center','center','center']" data-y="['middle','middle','middle','middle']" id="slide-5-layer-1" style="z-index: 5;background-color:rgba(0, 0, 0, 0.25);border-color:rgba(0, 0, 0, 0);"></div>
					<div class="tp-caption" data-fontsize="['72','62','50','28']" data-frames="[{&quot;delay&quot;:500,&quot;speed&quot;:1500,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;x:[175%];y:0px;z:0;rX:0;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:1;&quot;,&quot;mask&quot;:&quot;x:[-100%];y:0;s:inherit;e:inherit;&quot;,&quot;to&quot;:&quot;o:1;&quot;,&quot;ease&quot;:&quot;Power3.easeOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:300,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;opacity:0;&quot;,&quot;ease&quot;:&quot;nothing&quot;}]" data-height="['81','66','61','36']" data-hoffset="['29','21','-4','-3']" data-lineheight="['80','65','60','34']" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingtop="[0,0,0,0]" data-responsive="off" data-responsive_offset="off" data-textalign="['left','left','center','center']" data-type="text" data-voffset="['392','386','-110','-64']" data-whitespace="nowrap" data-width="['385','333','271','152']" data-x="['left','left','center','center']" data-y="['bottom','bottom','middle','middle']" id="slide-5-layer-2" style="z-index: 6; min-width: 385px; max-width: 385px; max-width: 81px; max-width: 81px; white-space: nowrap; font-size: 72px; line-height: 80px; font-weight: 400; color: rgba(255, 255, 255, 1.00);font-family: 'latoregular';">
						Pediatrics
					</div>
					<div class="tp-caption" data-fontsize="['30','26','22','16']" data-frames="[{&quot;delay&quot;:500,&quot;speed&quot;:1500,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;x:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;&quot;,&quot;mask&quot;:&quot;x:0px;y:0px;s:inherit;e:inherit;&quot;,&quot;to&quot;:&quot;o:1;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:300,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;opacity:0;&quot;,&quot;ease&quot;:&quot;nothing&quot;}]" data-height="['73','none','57','41']" data-hoffset="['30','24','-3','-4']" data-lineheight="['36','30','28','20']" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingtop="[0,0,0,0]" data-responsive="off" data-responsive_offset="off" data-textalign="['left','left','center','center']" data-type="text" data-voffset="['315','315','-46','-24']" data-whitespace="nowrap" data-width="['422','none','307','225']" data-x="['left','left','center','center']" data-y="['bottom','bottom','middle','middle']" id="slide-5-layer-3" style="z-index: 7; min-width: 422px; max-width: 422px; max-width: 73px; max-width: 73px; white-space: nowrap; font-size: 30px; line-height: 36px; font-weight: 300; color: rgba(255, 255, 255, 1.00);font-family: 'latolight';">
						Renowned pediatricians work at<br>
						MedLife Pediatric Hospital.
					</div><a class="tp-caption rev-btn" data-actions="" data-frames="[{&quot;delay&quot;:500,&quot;speed&quot;:300,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;opacity:0;&quot;,&quot;to&quot;:&quot;o:1;&quot;,&quot;ease&quot;:&quot;Power2.easeInOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:300,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;opacity:0;&quot;,&quot;ease&quot;:&quot;nothing&quot;},{&quot;frame&quot;:&quot;hover&quot;,&quot;speed&quot;:&quot;0&quot;,&quot;ease&quot;:&quot;Linear.easeNone&quot;,&quot;force&quot;:true,&quot;to&quot;:&quot;o:1;rX:0;rY:0;rZ:0;z:0;&quot;,&quot;style&quot;:&quot;c:rgba(255, 255, 255, 1.00);bg:rgba(76, 171, 76, 1.00);bs:solid;bw:0 0 0 0;&quot;}]" data-height="['53','53','54','42']" data-hoffset="['31','26','-2','-2']" data-lineheight="['28','28','28','16']" data-paddingbottom="[12,12,12,12]" data-paddingleft="[35,35,35,35]" data-paddingright="[35,35,35,35]" data-paddingtop="[12,12,12,12]" data-responsive="off" data-responsive_offset="off" data-textalign="['left','left','center','center']" data-type="button" data-voffset="['241','241','27','27']" data-whitespace="nowrap" data-width="['148','148','210','151']" data-x="['left','left','center','center']" data-y="['bottom','bottom','middle','middle']" href="services/index.html" id="slide-5-layer-4" style="z-index: 8; min-width: 148px; max-width: 148px; max-width: 53px; max-width: 53px; white-space: nowrap; font-size: 14px; line-height: 28px; font-weight: 700; color: rgba(255, 255, 255, 1.00);font-family: 'latoregular';background-color:rgba(102, 204, 102, 1.00);border-color:rgba(0, 0, 0, 1.00);border-radius:3px 3px 3px 3px;outline:none;box-shadow:none;box-sizing:border-box;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;cursor:pointer;" target="_self">FIND MORE</a>
				</li><!-- SLIDE  -->
			</ul>
			<div class="tp-static-layers" style="">
				<div class="tp-caption tp-shape tp-shapewrapper tp-static-layer" data-endslide="4" data-frames="[{&quot;delay&quot;:0,&quot;speed&quot;:300,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;opacity:0;&quot;,&quot;to&quot;:&quot;o:1;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:300,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;opacity:0;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;}]" data-height="['330','334','273','273']" data-hoffset="['29','26','0','0']" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingtop="[0,0,0,0]" data-responsive="off" data-responsive_offset="off" data-startslide="0" data-textalign="['inherit','inherit','inherit','inherit']" data-type="shape" data-voffset="['180','180','-7','-7']" data-whitespace="nowrap" data-width="['296','251','697','697']" data-x="['right','right','center','center']" data-y="['bottom','bottom','bottom','bottom']" id="slider-1-layer-24" style="z-index: 25;font-family:Open Sans;background-color:rgba(255, 255, 255, 1.00);border-color:rgba(0, 0, 0, 0);"></div>
				<div class="tp-caption tp-static-layer" data-endslide="4" data-frames="[{&quot;delay&quot;:0,&quot;speed&quot;:300,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;opacity:0;&quot;,&quot;to&quot;:&quot;o:1;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:300,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;opacity:0;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;}]" data-height="none" data-hoffset="['244','209','-151','-151']" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingtop="[0,0,0,0]" data-responsive="off" data-responsive_offset="off" data-startslide="0" data-textalign="['inherit','inherit','inherit','inherit']" data-type="image" data-voffset="['421','421','172','172']" data-whitespace="nowrap" data-width="none" data-x="['right','right','center','center']" data-y="['bottom','bottom','bottom','bottom']" id="slider-1-layer-25" style="z-index: 26;"><img alt="" data-hh="['46px','46px','46px','46px']" data-no-retina="" data-ww="['46px','46px','46px','46px']" height="70" src="images/appointment.png" width="70"></div>
				<div class="tp-caption tp-static-layer" data-endslide="4" data-frames="[{&quot;delay&quot;:0,&quot;speed&quot;:300,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;opacity:0;&quot;,&quot;to&quot;:&quot;o:1;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:300,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;opacity:0;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;}]" data-height="none" data-hoffset="['242','207','-149','-149']" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingtop="[0,0,0,0]" data-responsive="off" data-responsive_offset="off" data-startslide="0" data-textalign="['inherit','inherit','inherit','inherit']" data-type="image" data-voffset="['329','329','103','103']" data-whitespace="nowrap" data-width="none" data-x="['right','right','center','center']" data-y="['bottom','bottom','bottom','bottom']" id="slider-1-layer-26" style="z-index: 27;"><img alt="" data-hh="['48px','48px','48px','48px']" data-no-retina="" data-ww="['48px','48px','48px','48px']" height="70" src="images/services.png" width="70"></div>
				<div class="tp-caption tp-static-layer" data-endslide="4" data-frames="[{&quot;delay&quot;:0,&quot;speed&quot;:300,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;opacity:0;&quot;,&quot;to&quot;:&quot;o:1;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:300,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;opacity:0;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;}]" data-height="none" data-hoffset="['243','208','-150','-150']" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingtop="[0,0,0,0]" data-responsive="off" data-responsive_offset="off" data-startslide="0" data-textalign="['inherit','inherit','inherit','inherit']" data-type="image" data-voffset="['226','226','44','44']" data-whitespace="nowrap" data-width="none" data-x="['right','right','center','center']" data-y="['bottom','bottom','bottom','bottom']" id="slider-1-layer-27" style="z-index: 28;"><img alt="" data-hh="['46px','46px','46px','46px']" data-no-retina="" data-ww="['46px','46px','46px','46px']" height="70" src="images/test-results.png" width="70"></div><a class="tp-caption hover1 tp-static-layer" data-actions="" data-endslide="4" data-frames="[{&quot;delay&quot;:0,&quot;speed&quot;:300,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;opacity:0;&quot;,&quot;to&quot;:&quot;o:1;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:300,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;opacity:0;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;}]" data-height="27" data-hoffset="['110','86','-5','-5']" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingtop="[0,0,0,0]" data-responsive="off" data-responsive_offset="off" data-startslide="0" data-textalign="['inherit','inherit','inherit','inherit']" data-type="text" data-voffset="['445','445','194','194']" data-whitespace="nowrap" data-width="['106','104','104','104']" data-x="['right','right','center','center']" data-y="['bottom','bottom','bottom','bottom']" href="timetable.html" id="slider-1-layer-28" style="z-index: 29; min-width: 106px; max-width: 106px; max-width: 27px; max-width: 27px; white-space: nowrap; font-size: 13px; line-height: 26px; font-weight: 700; color: rgba(51, 51, 51, 1.00);font-family: 'latoregular'; font-weight: 700; text-decoration: none;" target="_self">APPOINTMENTS</a>
				<div class="tp-caption tp-static-layer" data-endslide="4" data-frames="[{&quot;delay&quot;:0,&quot;speed&quot;:300,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;opacity:0;&quot;,&quot;to&quot;:&quot;o:1;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:300,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;opacity:0;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;}]" data-height="['none','none','34','34']" data-hoffset="['69','44','14','14']" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingtop="[0,0,0,0]" data-responsive="off" data-responsive_offset="off" data-startslide="0" data-textalign="['inherit','inherit','center','center']" data-type="text" data-voffset="['412','412','156','156']" data-whitespace="['normal','normal','nowrap','nowrap']" data-width="['146','146','262','262']" data-x="['right','right','center','center']" data-y="['bottom','bottom','bottom','bottom']" id="slider-1-layer-29" style="z-index: 30; min-width: 146px; max-width: 146px; white-space: normal; font-size: 12px; line-height: 16px; font-weight: 400; color: rgba(102, 102, 102, 1.00);font-family: 'latoregular';">
					<strong>MON-FRI</strong>: 09:00-18:00 <strong>SAT-SUN</strong>: 10:00 - 14:00
				</div><a class="tp-caption hover2 tp-static-layer" data-actions="" data-endslide="4" data-frames="[{&quot;delay&quot;:0,&quot;speed&quot;:300,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;opacity:0;&quot;,&quot;to&quot;:&quot;o:1;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:300,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;opacity:0;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;}]" data-height="27" data-hoffset="['150','126','-6','-6']" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingtop="[0,0,0,0]" data-responsive="off" data-responsive_offset="off" data-startslide="0" data-textalign="['inherit','inherit','center','center']" data-type="text" data-voffset="['353','352','126','126']" data-whitespace="nowrap" data-width="['63','62','104','104']" data-x="['right','right','center','center']" data-y="['bottom','bottom','bottom','bottom']" href="service.html" id="slider-1-layer-30" style="z-index: 31; min-width: 63px; max-width: 63px; max-width: 27px; max-width: 27px; white-space: nowrap; font-size: 13px; line-height: 26px; font-weight: 700; color: rgba(51, 51, 51, 1.00);font-family: 'latoregular'; font-weight: 700; text-decoration: none;" target="_self">SERVICES</a> <a class="tp-caption hover3 tp-static-layer" data-actions="" data-endslide="4" data-frames="[{&quot;delay&quot;:0,&quot;speed&quot;:300,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;opacity:0;&quot;,&quot;to&quot;:&quot;o:1;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:300,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;opacity:0;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;}]" data-height="27" data-hoffset="['113','101','-4','-4']" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingtop="[0,0,0,0]" data-responsive="off" data-responsive_offset="off" data-startslide="0" data-textalign="['inherit','inherit','center','center']" data-type="text" data-voffset="['258','257','63','63']" data-whitespace="nowrap" data-width="['106','88','104','104']" data-x="['right','right','center','center']" data-y="['bottom','bottom','bottom','bottom']" href="diagnostic-service.html" id="slider-1-layer-31" style="z-index: 32; min-width: 106px; max-width: 106px; max-width: 27px; max-width: 27px; white-space: nowrap; font-size: 13px; line-height: 26px; font-weight: 700; color: rgba(51, 51, 51, 1.00);font-family: 'latoregular'; font-weight: 700; text-decoration: none;" target="_self">TEST RESULTS</a>
				<div class="tp-caption tp-static-layer" data-endslide="4" data-frames="[{&quot;delay&quot;:0,&quot;speed&quot;:300,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;opacity:0;&quot;,&quot;to&quot;:&quot;o:1;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:300,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;opacity:0;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;}]" data-height="['none','34','34','34']" data-hoffset="['82','57','9','9']" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingtop="[0,0,0,0]" data-responsive="off" data-responsive_offset="off" data-startslide="0" data-textalign="['inherit','inherit','center','center']" data-type="text" data-voffset="['321','322','90','90']" data-whitespace="['normal','normal','nowrap','nowrap']" data-width="['131','131','262','262']" data-x="['right','right','center','center']" data-y="['bottom','bottom','bottom','bottom']" id="slider-1-layer-32" style="z-index: 33; min-width: 131px; max-width: 131px; white-space: normal; font-size: 13px; line-height: 16px; font-weight: 400; color: rgba(102, 102, 102, 1.00);font-family: 'latoregular';">
					Check our list of services and prices.
				</div>
				<div class="tp-caption tp-static-layer" data-endslide="4" data-frames="[{&quot;delay&quot;:0,&quot;speed&quot;:300,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;opacity:0;&quot;,&quot;to&quot;:&quot;o:1;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:300,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;opacity:0;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;}]" data-height="['35','34','34','34']" data-hoffset="['91','58','9','9']" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingtop="[0,0,0,0]" data-responsive="off" data-responsive_offset="off" data-startslide="0" data-textalign="['inherit','inherit','center','center']" data-type="text" data-voffset="['226','226','26','26']" data-whitespace="['normal','normal','nowrap','nowrap']" data-width="['124','131','262','262']" data-x="['right','right','center','center']" data-y="['bottom','bottom','bottom','bottom']" id="slider-1-layer-33" style="z-index: 34; min-width: 124px; max-width: 124px; max-width: 35px; max-width: 35px; white-space: normal; font-size: 13px; line-height: 16px; font-weight: 400; color: rgba(102, 102, 102, 1.00);font-family: 'latoregular';">
					You can check your test results online.
				</div><!-- <div class="tp-caption   tp-svg-layer  arrow1 tp-static-layer" id="slider-1-layer-34" data-x="['right','right','center','center']" data-hoffset="['56','43','162','162']" data-y="['bottom','bottom','bottom','bottom']" data-voffset="['432','432','181','181']" data-width="24" data-height="24" data-whitespace="normal" data-type="svg" data-svg_src="images/ic_keyboard_arrow_right_24px.svg" data-svg_idle="sc:transparent;sw:0;sda:0;sdo:0;" data-responsive_offset="off" data-responsive="off" data-startslide="0" data-endslide="4" data-frames="[{&quot;delay&quot;:0,&quot;speed&quot;:300,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;opacity:0;&quot;,&quot;to&quot;:&quot;o:1;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:300,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;opacity:0;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;}]" data-textalign="['inherit','inherit','inherit','inherit']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="z-index: 35; min-width: 24px; max-width: 24px; color: rgb(70, 191, 0); font-family: &quot;Open Sans&quot;; visibility: inherit; transition: none; text-align: inherit; line-height: 22px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 400; font-size: 13px; white-space: normal; min-height: 24px; max-height: 24px; opacity: 1; transform: matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1); transform-origin: 50% 50% 0px;" src="images/ic_keyboard_arrow_right_24px.svg"> <div class="tp-svg-innercontainer"><svg width="24" height="24" viewBox="0 0 24 24" style="fill: rgb(70, 191, 0);"><path d="M8.59 16.34l4.58-4.59-4.58-4.59L10 5.75l6 6-6 6z" style="fill: rgb(70, 191, 0);"></path></svg></div></div>

						<div class="tp-caption   tp-svg-layer  arrow2 tp-static-layer" id="slider-1-layer-35" data-x="['right','right','center','center']" data-hoffset="['56','43','162','162']" data-y="['bottom','bottom','bottom','bottom']" data-voffset="['347','347','111','111']" data-width="24" data-height="24" data-whitespace="normal" data-type="svg" data-svg_src="images/ic_keyboard_arrow_right_24px.svg" data-svg_idle="sc:transparent;sw:0;sda:0;sdo:0;" data-responsive_offset="off" data-responsive="off" data-startslide="0" data-endslide="4" data-frames="[{&quot;delay&quot;:0,&quot;speed&quot;:300,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;opacity:0;&quot;,&quot;to&quot;:&quot;o:1;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:300,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;opacity:0;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;}]" data-textalign="['inherit','inherit','inherit','inherit']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="z-index: 36; min-width: 24px; max-width: 24px; color: rgb(70, 191, 0); font-family: &quot;Open Sans&quot;; visibility: inherit; transition: none; text-align: inherit; line-height: 22px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 400; font-size: 13px; white-space: normal; min-height: 24px; max-height: 24px; opacity: 1; transform: matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1); transform-origin: 50% 50% 0px;" src="images/ic_keyboard_arrow_right_24px.svg"> <div class="tp-svg-innercontainer"><svg width="24" height="24" viewBox="0 0 24 24" style="fill: rgb(70, 191, 0);"><path d="M8.59 16.34l4.58-4.59-4.58-4.59L10 5.75l6 6-6 6z" style="fill: rgb(70, 191, 0);"></path></svg></div></div>

						<div class="tp-caption   tp-svg-layer  arrow3 tp-static-layer" id="slider-1-layer-36" data-x="['right','right','center','center']" data-hoffset="['56','43','162','162']" data-y="['bottom','bottom','bottom','bottom']" data-voffset="['245','245','54','54']" data-width="24" data-height="24" data-whitespace="normal" data-type="svg" data-svg_src="images/ic_keyboard_arrow_right_24px.svg" data-svg_idle="sc:transparent;sw:0;sda:0;sdo:0;" data-responsive_offset="off" data-responsive="off" data-startslide="0" data-endslide="4" data-frames="[{&quot;delay&quot;:0,&quot;speed&quot;:300,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;opacity:0;&quot;,&quot;to&quot;:&quot;o:1;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:300,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;opacity:0;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;}]" data-textalign="['inherit','inherit','inherit','inherit']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="z-index: 37; min-width: 24px; max-width: 24px; color: rgb(70, 191, 0); font-family: &quot;Open Sans&quot;; visibility: inherit; transition: none; text-align: inherit; line-height: 22px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 400; font-size: 13px; white-space: normal; min-height: 24px; max-height: 24px; opacity: 1; transform: matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1); transform-origin: 50% 50% 0px;" src="images/ic_keyboard_arrow_right_24px.svg"> <div class="tp-svg-innercontainer"><svg width="24" height="24" viewBox="0 0 24 24" style="fill: rgb(70, 191, 0);"><path d="M8.59 16.34l4.58-4.59-4.58-4.59L10 5.75l6 6-6 6z" style="fill: rgb(70, 191, 0);"></path></svg></div></div> -->
			</div>
		</div>
	</div><!-- Slider End -->

    <div class="services-section">
		<div class="container">
			<div class="services-main-blocks">
				<div class="services-box">
					<div class="grid-box-inner">
						<a href="#">
						<div class="item-title">
							<div class="icon-wrp"><img alt="" class="img-responsive" src="images/ambulatory.png"></div>
							<div class="title-wrp">
								<h3>AMBULATORY</h3>
							</div>
						</div><!--/.item-title-->
						<div class="description clearfix">
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut</p>
						</div></a>
					</div><!--/.grid-box-inner-->
				</div><!--/.services-box-->
				<div class="services-box">
					<div class="grid-box-inner">
						<a href="#">
						<div class="item-title">
							<div class="icon-wrp"><img alt="" class="img-responsive" src="images/vaccination.png"></div>
							<div class="title-wrp">
								<h3>VACCINATION</h3>
							</div>
						</div><!--/.item-title-->
						<div class="description clearfix">
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut</p>
						</div></a>
					</div><!--/.grid-box-inner-->
				</div><!--/.services-box-->
				<div class="services-box">
					<div class="grid-box-inner">
						<a href="#">
						<div class="item-title">
							<div class="icon-wrp"><img alt="" class="img-responsive" src="images/surgery.png"></div>
							<div class="title-wrp">
								<h3>GENERAL<br>
								SURGERY</h3>
							</div>
						</div>
						<div class="description clearfix">
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut</p>
						</div></a>
					</div><!--/.grid-box-inner-->
				</div><!--/.services-box-->
				<div class="services-box">
					<div class="grid-box-inner">
						<a href="#">
						<div class="item-title">
							<div class="icon-wrp"><img alt="" class="img-responsive" src="images/physician.png"></div>
							<div class="title-wrp">
								<h3>PHYSICIANS</h3>
							</div>
						</div><!--/.item-title-->
						<div class="description clearfix">
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut</p>
						</div></a>
					</div><!--/.grid-box-inner-->
				</div><!--/.services-box-->
			</div><!--/.services-main-blocks-->
		</div><!--/.container-->
	</div><!-- Services-section End -->



    <div class="our-work-profile clearfix">
		<div class="container">
			<!-- Section Title Start -->
			<div class="section-title clearfix">
				<h3>WHO WE ARE</h3>
			</div><!-- Section Title End -->
			<!-- Work Profile Tabing Start -->
			<div class="work-profile-tabing clearfix">
				<div class="col-sm-5 col-md-4 col-lg-3 padding">
					<div class="left-side">
						<!-- Nav tabs -->
						<ul class="nav nav-tabs" role="tablist">
							<li class="active">
								<a data-toggle="tab" href="#schedule" role="tab">Schedule Your Appointment <i aria-hidden="true" class="fa fa-plus"></i></a>
							</li>
							<li>
								<a data-toggle="tab" href="#medlife" role="tab">Why Medlife Care ? <i aria-hidden="true" class="fa fa-eye"></i></a>
							</li>
							<li>
								<a data-toggle="tab" href="#community" role="tab">Our Community <i aria-hidden="true" class="fa fa-heart-o"></i></a>
							</li>
							<li>
								<a data-toggle="tab" href="#trusted" role="tab">25 Years of trusted Care <i aria-hidden="true" class="fa fa-clock-o"></i></a>
							</li>
						</ul><!--/.nav nav-tabs-->
					</div><!--/.left-side-->
				</div><!--/.col-sm-5 col-md-4 col-lg-3 padding-->
				<div class="col-sm-7 col-md-8 col-lg-9 padding">
					<div class="right-side">
						<!-- Tab panes -->
						<div class="tab-content">
							<div class="tab-pane fade in active" id="schedule">
								<h4>Schedule an online Appointment, if you do not see a time that is convenient for you, please call us at <a href="tel:888-808-6483">888-808-6483</a>.</h4>
								<p>Doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.</p>
								<p>Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam qua.</p>
							</div><!--/.tab-pane-->
							<div class="tab-pane fade" id="medlife">
								<h4>Schedule an online Appointment, if you do not see a time that is convenient for you, please call us at <a href="tel:888-808-6483">888-808-6483</a>.</h4>
								<p>Doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.</p>
								<p>Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam qua.</p>
							</div><!--/.tab-pane-->
							<div class="tab-pane fade" id="community">
								<h4>Schedule an online Appointment, if you do not see a time that is convenient for you, please call us at <a href="tel:888-808-6483">888-808-6483</a>.</h4>
								<p>Doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.</p>
								<p>Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam qua.</p>
							</div><!--/.tab-pane-->
							<div class="tab-pane fade" id="trusted">
								<h4>Schedule an online Appointment, if you do not see a time that is convenient for you, please call us at <a href="tel:888-808-6483">888-808-6483</a>.</h4>
								<p>Doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.</p>
								<p>Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam qua.</p>
							</div><!--/.tab-pane-->
						</div><!--/.tab-content-->
					</div><!--/.right-side-->
				</div><!--/.col-sm-7 col-md-8 col-lg-9 padding-->
			</div><!-- Work Profile Tabing End -->
			<!-- Our Treatment Start -->
			<div class="our-treatment clearfix">
				<div class="row">
					<div class="col-sm-6 col-md-3">
						<div class="treatment-block clearfix">
							<img alt="ICON" class="img-responsive" src="images/emergency-icon2.png">
							<h5>Medical Treatment</h5>
							<p>Lorem ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna.</p>
						</div><!--/.treatment-block-->
					</div><!--/.col-sm-6 col-md-3-->
					<div class="col-sm-6 col-md-3">
						<div class="treatment-block clearfix">
							<img alt="ICON" class="img-responsive" src="images/emergency-icon3.png">
							<h5>Emergency Help</h5>
							<p>Lorem ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna.</p>
						</div><!--/.treatment-block-->
					</div><!--/.col-sm-6 col-md-3-->
					<div class="col-sm-6 col-md-3">
						<div class="treatment-block clearfix">
							<img alt="ICON" class="img-responsive" src="images/emergency-icon1.png">
							<h5>Medical professionals</h5>
							<p>Lorem ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna.</p>
						</div><!--/.treatment-block-->
					</div><!--/.col-sm-6 col-md-3-->
					<div class="col-sm-6 col-md-3">
						<div class="treatment-block clearfix">
							<img alt="ICON" class="img-responsive" src="images/emergency-icon4.png">
							<h5>Qualified Doctors</h5>
							<p>Lorem ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna.</p>
						</div><!--/.treatment-block-->
					</div><!--/.col-sm-6 col-md-3-->
				</div><!--/.row-->
			</div><!-- Our Treatment End -->
		</div><!--/.container-->
	</div><!-- Our Work Profile End -->

    <section class="content inner-pg service-pg clearfix">
		<!-- Breadcrumb Start -->
		
		<div class="container">
			<!-- Inner Pages Start -->
			<div class="inner-content clearfix">
				<div class="row">
					<div class="col-sm-12 col-md-8 col-lg-9">
						<!-- Content Description Start -->
						<div class="content-desc clearfix">
							<!-- Banner Start -->
							
							<!-- Service Detail Block Start -->
							
							<!-- Human Body Parts Start -->
							<div class="human-body-parts clearfix">
								<div class="row">
									<div class="col-xs-6 col-sm-6 col-md-6 col-lg-4">
										<div class="body-parts-block">
											<div class="icon purple-txt">
												<i class="flaticon-human-lungs"></i>
											</div>
											<h6>Pulmonary</h6>
											<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
										</div><!--/.body-parts-block-->
									</div><!--/.col-xs-6 col-sm-6 col-md-6 col-lg-4-->
									<div class="col-xs-6 col-sm-6 col-md-6 col-lg-4">
										<div class="body-parts-block">
											<div class="icon red-txt">
												<i class="flaticon-human-heart"></i>
											</div>
											<h6>Cardiology</h6>
											<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
										</div><!--/.body-parts-block-->
									</div><!--/.col-xs-6 col-sm-6 col-md-6 col-lg-4-->
									<div class="col-xs-6 col-sm-6 col-md-6 col-lg-4">
										<div class="body-parts-block">
											<div class="icon red-txt">
												<i class="flaticon-human-head"></i>
											</div>
											<h6>Cosmetic Solutions</h6>
											<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
										</div><!--/.body-parts-block-->
									</div><!--/.col-xs-6 col-sm-6 col-md-6 col-lg-4-->
									<div class="col-xs-6 col-sm-6 col-md-6 col-lg-4">
										<div class="body-parts-block">
											<div class="icon green-txt">
												<i class="flaticon-eyeball-structure"></i>
											</div>
											<h6>Eye</h6>
											<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
										</div><!--/.body-parts-block-->
									</div><!--/.col-xs-6 col-sm-6 col-md-6 col-lg-4-->
									<div class="col-xs-6 col-sm-6 col-md-6 col-lg-4">
										<div class="body-parts-block">
											<div class="icon sky-txt">
												<i class="flaticon-tooth-and-gums"></i>
											</div>
											<h6>Dental care</h6>
											<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
										</div><!--/.body-parts-block-->
									</div><!--/.col-xs-6 col-sm-6 col-md-6 col-lg-4-->
									<div class="col-xs-6 col-sm-6 col-md-6 col-lg-4">
										<div class="body-parts-block">
											<div class="icon orange-txt">
												<i class="flaticon-human-ear"></i>
											</div>
											<h6>Ear treatment</h6>
											<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
										</div><!--/.body-parts-block-->
									</div><!--/.col-xs-6 col-sm-6 col-md-6 col-lg-4-->
									<div class="col-xs-6 col-sm-6 col-md-6 col-lg-4">
										<div class="body-parts-block">
											<div class="icon dark-green-txt">
												<i class="flaticon-basophil"></i>
											</div>
											<h6>Urology</h6>
											<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
										</div><!--/.body-parts-block-->
									</div><!--/.col-xs-6 col-sm-6 col-md-6 col-lg-4-->
									<div class="col-xs-6 col-sm-6 col-md-6 col-lg-4">
										<div class="body-parts-block">
											<div class="icon maroon-txt">
												<i class="flaticon-spine-bone"></i>
											</div>
											<h6>X-ray</h6>
											<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
										</div><!--/.body-parts-block-->
									</div><!--/.col-xs-6 col-sm-6 col-md-6 col-lg-4-->
									<div class="col-xs-6 col-sm-6 col-md-6 col-lg-4">
										<div class="body-parts-block">
											<div class="icon violet-txt">
												<i class="flaticon-neuron"></i>
											</div>
											<h6>Neurology</h6>
											<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
										</div><!--/.body-parts-block-->
									</div><!--/.col-xs-6 col-sm-6 col-md-6 col-lg-4-->
									<div class="col-xs-6 col-sm-6 col-md-6 col-lg-4">
										<div class="body-parts-block">
											<div class="icon violet-txt">
												<i class="flaticon-fertilization"></i>
											</div>
											<h6>Fertility</h6>
											<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
										</div><!--/.body-parts-block-->
									</div><!--/.col-xs-6 col-sm-6 col-md-6 col-lg-4-->
									<div class="col-xs-6 col-sm-6 col-md-6 col-lg-4">
										<div class="body-parts-block">
											<div class="icon violet-txt">
												<i class="flaticon-small-intestine"></i>
											</div>
											<h6>Gastroenterology</h6>
											<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
										</div><!--/.body-parts-block-->
									</div><!--/.col-xs-6 col-sm-6 col-md-6 col-lg-4-->
                                    <div class="col-xs-6 col-sm-6 col-md-6 col-lg-4">
										<div class="body-parts-block">
											<div class="icon violet-txt">
												<i class="flaticon-small-intestine"></i>
											</div>
											<h6>Gastroenterology</h6>
											<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
										</div><!--/.body-parts-block-->
									</div><!--/.col-xs-6 col-sm-6 col-md-6 col-lg-4-->
								</div><!--/.row-->
							</div><!-- Human Body Parts End -->
							<!-- Appointment Form Start -->
							
						</div><!-- Content Description End -->
					</div><!--/.col-sm-12 col-md-8 col-lg-9-->
					<div class="col-sm-12 col-md-4 col-lg-3">
						<!-- Sidebar Widget Start -->
						<div class="sidebar-widget clearfix">
							<!-- Widget Block Start -->
							<div class="widget-block">
								<!-- Medlife Service Start -->
								<div class="medlife-service blue-bg">
									<!-- Widget Title Start -->
									<div class="widget-title clearfix">
										<h6>Medlife Services</h6>
									</div><!-- Widget Title End -->
									<ul>
										<li>
											<a href="general-service.html">General and Preventive Care</a>
										</li>
										<li>
											<a href="cosmetic-solutions-service.html">Cosmetic Solutions</a>
										</li>
										<li>
											<a href="restorative-service.html">Restorative Solutions</a>
										</li>
										<li>
											<a href="additional-service.html">Additional Treatments</a>
										</li>
										<li>
											<a href="orthodontics-service.html">Orthodontics</a>
										</li>
										<li>
											<a href="dentures-service.html">Dentures & Denture Repair</a>
										</li>
										<li>
											<a href="diagnostic-service.html">Diagnostic & Preventive</a>
										</li>
										<li>
											<a href="pediatric-service.html">Pediatric Dentistry</a>
										</li>
									</ul>
								</div><!-- Medlife Service End -->
								<!-- Opening Hover Start -->
								<div class="opening-hours light-green-bg">
									<!-- Widget Title Start -->
									<div class="widget-title clearfix">
										<h6>Opening Hours</h6>
									</div><!-- Widget Title End -->
									<table class="table">
										<tbody>
											<tr>
												<td>Monday - Friday:</td>
												<td>8.30 - 18.30</td>
											</tr>
											<tr>
												<td>Saturday:</td>
												<td>10.30 - 16.30</td>
											</tr>
											<tr>
												<td>Sunday:</td>
												<td>10.30 - 16:30</td>
											</tr>
										</tbody>
									</table>
								</div><!-- Opening Hover End -->
							</div><!-- Widget Block End -->
							<!-- Widget Block Start -->
							<div class="widget-block">
								<!-- News Letter Start -->
								<div class="news-letter gray-bg">
									<!-- Widget Title Start -->
									<div class="widget-title clearfix">
										<h6>News Letters</h6>
									</div><!-- Widget Title End -->
									<form action="//YOUR_USERNAME.DATASERVER.list-manage.com/subscribe/post?u=YOUR_API_KEY&id=LIST_ID" class="md__newsletter-form" id="mc-embedded-subscribe-form" method="post" name="mc-embedded-subscribe-form" novalidate="" target="_blank">
										<div>
											<input class="email form-control" name="EMAIL" placeholder="Email address" required="" type="email" value="">
											<div aria-hidden="true" style="position: absolute; left: -5000px;">
												<input name="b_78185f3823fef6dc6a261e0df_2ebd195299" tabindex="-1" type="text" value="">
											</div><button class="btn btn-default" id="mc-embedded-subscribe1" name="SEND" type="submit">Subscribe</button>
										</div>
										<div class="md__newsletter-message"></div>
									</form>
								</div><!-- News Letter End -->
							</div><!-- Widget Block End -->
							<!-- Widget Block Start -->
							<div class="widget-block">
								<!-- Recent News Start -->
								<div class="recent-news white-bg">
									<!-- Widget Title Start -->
									<div class="widget-title clearfix">
										<h6>Recent Newss</h6>
									</div><!-- Widget Title End -->
									<a href="#">VIEW ALL</a>
									<div class="recent-block">
										<a href="#">Ultrasmall nanoparticles kill cancer cells in unusual way</a>
										<p><i aria-hidden="true" class="fa fa-clock-o"></i> September 30, 2016</p>
									</div>
									<div class="recent-block">
										<a href="#">Eye lens regeneration from own stem cells</a>
										<p><i aria-hidden="true" class="fa fa-clock-o"></i> September 30, 2016</p>
									</div>
								</div><!-- Recent News End -->
							</div><!-- Widget Block End -->
						</div><!-- Sidebar Widget End -->
					</div><!--/.col-sm-12 col-md-4 col-lg-3-->
				</div><!--/.row-->
			</div><!-- Inner Pages End -->
		</div><!--/.container-->
	</section><!-- Content End -->

                            
<?php require_once('footer.php') ?>