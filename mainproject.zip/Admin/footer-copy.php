<div class="page-footer">
                    <p class="no-s"><?php echo date('Y') ?> &copy; Medlife.</p>
                </div>