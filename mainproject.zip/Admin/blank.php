<?Php require_once('header.php') ?>
<?Php require_once('menu.php') ?> 
            <div class="page-inner">
                <div class="page-title">
                    <h3>Blank Page</h3>
                    <div class="page-breadcrumb">
                        <ol class="breadcrumb">
                            <li><a href="index.html">Home</a></li>
                            <li><a href="#">Layouts</a></li>
                            <li class="active">Blank Page</li>
                        </ol>
                    </div>
                </div>
                <div id="main-wrapper">
                    <div class="row">

                    xxd
                    </div><!-- Row -->
            </div><!-- Main Wrapper -->
                
                
                <?Php require_once('footer.php') ?>             